#WARDEN PROTOCOL AUTO SEND WARD TOKEN
## Clone
```git clone https://guthub.com/alexswanFantom/warden```
## Open file
```
1. cd warden
2. edit file ward.js in line 88 and 93. if you using mnemonic edit on line 93 and paste your mnemonic, and if you using privateKey, edit on line 88, paste your privateKey, and edit on line 96 'wallets' to 'wallet'.

```
## Running
```
node ward.js

```

## CATATAN
```if you havn't address.txt in your directory, the first run bot will generate 150 addresses. and you have to run 'node ward.js' a second time```

